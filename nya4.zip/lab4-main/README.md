# Getting Started with Create React App

прописываем npm i для добавления node_modules

## Available Scripts

после нажимаем 

### `npm start`

Runs the app in the development mode.\
Open [http://localhost:3000](http://localhost:3000) to view it in your browser.

The page will reload when you make changes.\
You may also see any lint errors in the console.

Отчет: https://docs.google.com/document/d/1cE6e6NqS0TwoTl2wyM-ppaoVuQd6l6p87_-i7LiIJ6M/edit?usp=sharing